module.exports = {
    token: "토큰을 입력하세요.",
    clientId: 'https://discord.com/developers/applications - clientId를 입력하세요.',
    adminRoleId: '관리자 역할 ID을 입력하세요.',
};